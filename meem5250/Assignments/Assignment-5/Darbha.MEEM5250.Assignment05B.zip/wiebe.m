function [ x_b ] = wiebe(CA,CA0,CA90,m,a)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
x_b = 1-exp(-a*((CA-CA0)/(CA90-CA0)).^m);


end

