function cancel_but

%   Function to close open window without saving any input.
%   Called by Reactant_Species.m
%
%   KMF     April 27/05 Rev 1
%

close