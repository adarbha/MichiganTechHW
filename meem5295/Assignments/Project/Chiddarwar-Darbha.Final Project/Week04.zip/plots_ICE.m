%%
% Author: J.D.Naber
%
%
%  Date: 2011-03-12
%
clear all;
close all;
clc;

%%
Vehicle_Init_File

%% Plots
% Font Size
fs = 16;                            % Font Size

%%
T = Engine_Torque_2DMAP_Nm;
B = Engine_BSFC_2DMAP_g_kWh;

N  = Engine_2DMAP_Index_RPM;
N  = N'*ones(1,size(T,2));

P  = 2*pi*N.*T / 60 /1000;     % kW


TR  = Engine_2DMAP_Index_TR;
TR  = ones(size(T,1),1) * TR;

% N, Power        
figure;
    set(gcf, 'position', [50 50 650 500])

    h = plot(Engine_2DMAP_Index_RPM, T(:,end), 'r-d');
        axis([0 7000 0 400])
        set(h, 'LineWidth', 2, 'MarkerFaceColor', [0.8 0 0]);

        grid on;
        set(gca, 'position', [0.16 0.16 0.78 0.78])
        set(gca, 'fontsize', fs, 'fontname', 'Calibri');

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 10;         set(h, 'position', p);
        
        h = ylabel('Torque (N-m)');
        p = get(h, 'position');
        p(1) = p(1)- 75;         set(h, 'position', p);

% N, Power        
figure;
    set(gcf, 'position', [100 100 650 500])

    h = plot(Engine_2DMAP_Index_RPM, P(:,end), 'r-d');
        axis([0 7000 0 200])
        set(h, 'LineWidth', 2, 'MarkerFaceColor', [0.8 0 0]);

        grid on;
        set(gca, 'position', [0.16 0.16 0.78 0.78])
        set(gca, 'fontsize', fs, 'fontname', 'Calibri');

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 10;         set(h, 'position', p);
        
        h = ylabel('Power (kW)');
        p = get(h, 'position');
        p(1) = p(1)- 75;         set(h, 'position', p);
        
        

figure;
    set(gcf, 'position', [150 150 650 500])
    contourf(N,TR, T, [0:25:330]);
        caxis([0 330]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1.001])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);
        
        title('Torque (N-m)');

figure;
    set(gcf, 'position', [200 200 650 500])
    contourf(N,TR, 4*pi*T/(Engine_Displacement_L/1e3)/1e5, [0:1:12]);
        caxis([0 12]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1.001])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);
        
        title('BMEP (bar)');        
        
        
        
figure;
    set(gcf, 'position', [250 250 650 500])
    contourf(N,TR, P, [0:10:150]);
        caxis([0 150]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1.001])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);
        
        title('Power (kW)');
        
% Malibu
p_fit_00 = [0.0867263      2.3154950    216.6955298];   % TF = p(MPH)
V_RL_Contours = [10:10:140];                              % MPH
P_RL_Contours = 1609/3600/1000*polyval(p_fit_00, V_RL_Contours).*V_RL_Contours; % kW
figure;
    set(gcf, 'position', [300 300 650 500])
         
    
         contourf(N,TR, B, [187.5:12.5:700]);
         colorbar;
           hold on;
 
% These cause problems with Colorbar rescaling           
%         h = contour(N,TR, P, P_RL_Contours, 'y');
%         h = contour(N,TR, P, P_RL_Contours(6), 'w', 'linewidth', 2);

         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])
 
        
        
        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);

        title('BSFC (g/kW-hr)');

        saveas(h, 'BSFC_Road_Load.fig', 'fig');
        
        
%      Special colormap for gray scale        
%        caxis([-300 700]);
%        colormap('gray');

figure;
    set(gcf, 'position', [300 300 650 500])
% These cause problems with Colorbar rescaling so plot here separately
         h = contour(N,TR, P, P_RL_Contours, 'y');
         hold on;
         h = contour(N,TR, P, P_RL_Contours(6), 'w', 'linewidth', 2);

         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])
         set(gca,'xtick', [], 'ytick', []);
 

% Efficiency
c = 1/(Fuel_LHV_MJkg*1000)*1000*3600;
figure;
    set(gcf, 'position', [350 350 650 500])
    contourf(N,TR, 100*c./B, [[0:2:30] [31:41]]);
        caxis([0 40]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);

        title('Efficiency (%)');
        
% Opportunity Loss
figure;     
     set(gcf, 'position', [400 400 650 500])
     y = B;                         % BSFC
     ymin = min(min(y));            % Opporunity Loss
     y = (y-ymin)/ymin*100;
     dy = logspace(log10(2), log10(500),20);
     dy = [0 dy];
     contourf(N,TR, y, dy);
         caxis([0 150]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);

        title('Opporunity Cost (%)');        

       
% Efficiency        
figure;     set(gcf, 'position', [400 400 650 500])
     y = 100*c./B;    % Efficiency
     ymax = max(max(y));
     y = (ymax-y);
     contourf(N,TR, y, [0:5:100]);
         caxis([0 100]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);

        title('Efficiency Loss (%)');
        
        
if (true)
figure;     set(gcf, 'position', [400 400 650 500])
     y = 100*c./B;                      % Efficiency
     ymax = max(max(y));                
     y = (ymax-y)/(max(max(y)));        % Relative efficiency loss
     contourf(N,TR, y, [0:5:100]/100);
         caxis([0 1]);
         colorbar;
         grid on;
         set(gca, 'position', [0.12 0.17 0.70 0.75])
         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
         axis([800 6000 0.1 1])

        h = xlabel('Engine Speed (RPM)');
        p = get(h, 'position');
        p(2) = p(2)- 0.025;         set(h, 'position', p);
        
        h = ylabel('Torque Request (-)');
        p = get(h, 'position');
        p(1) = p(1)- 0.01;         set(h, 'position', p);

        title('Normalized Efficiency Loss (-)');        
end
        
clear h p c y ymax T B N P TR