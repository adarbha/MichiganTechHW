%% 
% Display results from MTU_HVM model
%
% JDN 2012-03-16
%

%%
close all;
clc;

fs = 14;

% figure;
%     set(gcf, 'position', [50 50 900 400]);
%     h = plot(TEST_CYCLE(:,1), TEST_CYCLE(:,2), 'r');
%         set(h, 'linewidth', 2.5);
%         set(gca, 'fontsize', fs, 'fontname', 'Calibri');
%         xlabel('Time (sec)');
%         ylabel('Vehicle Speed (mph)');
%         grid on;
        


disp('CYCLE RESULTS:');
disp('  Design Parameters:');
s = sprintf('\tVehicle Mass             =\t %5.0f \t(kg)',    Vehicle_Mass_kg);                                disp(s);
s = sprintf('\tVehicle Tire Radius      =\t %5.3f \t(m^2)',   Vehicle_Tire_Radius_m);                          disp(s);
s = sprintf('\tVehicle Tire Roll Resist =\t %5.3f \t(-)',     Vehicle_Tire_Coeff_Rolling_Resistance);          disp(s);
s = sprintf('\tVehicle Drag Coeff       =\t %5.3f \t(-)',     Vehicle_Drag_Coeff);                             disp(s);
s = sprintf('\tVehicle Frontal Area     =\t %5.3f \t(m^2)',   Vehicle_Frontal_Area_m);                         disp(s);

s = sprintf('\tICE Option               =\t %5d \t(-)',       ICE_Option);                                     disp(s);
s = sprintf('\tTrans Option             =\t %5d \t(-)',       Trans_Option);                                   disp(s);
s = sprintf('\tBattery Option           =\t %5d \t(-)',       Batt_Option);                                    disp(s);
s = sprintf('\tMotor Option             =\t %5d \t(-)',       Motor_Option);                                   disp(s);

s = sprintf('\tEngine Torque(Max)       =\t %5.0f \t(N-m)',   max(max(Engine_Torque_2DMAP_Nm)));               disp(s);
s = sprintf('\tEngine BSFC(Min)         =\t %5.0f \t(N-m)',   min(min(Engine_BSFC_2DMAP_g_kWh)));              disp(s);
s = sprintf('\tEngine ACC Loss          =\t %5.0f \t(N-m)',   Engine_ACC_Loss_Nm);                             disp(s);
s = sprintf('\tDifferential Ratio       =\t %5.3f \t(-)',     TRANS_Differential_Ratio);                       disp(s);
s = sprintf('\tMotor Gear Ratio         =\t %5.3f \t(-)',     Motor_Gear_Ratio);                               disp(s);

s = sprintf('\tBattery Aux Load         =\t %5.0f \t(W)',     Batt_Aux_Load_W);                                disp(s);
disp(' ');

%% Compute and display cycle parameters
E_Gas = 34.7;     % kW-hr / gal

% NEED TO CORRECT THIS BASED UPON INITIAL SOC
Cycle_Battery_Utilized_Ah         = Cycle_Battery_Utilized_Ah - (1-Batt_Initial_SOC)*Batt_Capacity_Ah;  % Ah


Cycle_Battery_Capacity_Energy_kwhr=  Batt_Capacity_Ah * Batt_Const_V / 1000;                           % kW-hr

Cycle_Battery_Initial_SOC         =  Batt_Initial_SOC;                                                 % Fraction (-)
Cycle_Battery_Initial_Charge_Ah   =  Batt_Initial_SOC*Batt_Capacity_Ah;                                % A-hr (-)
Cycle_Battery_Initial_Energy_kwhr =  Cycle_Battery_Initial_Charge_Ah* Batt_Const_V / 1000;             % kW-hr

Cycle_Battery_Utilized_kwhr       =  Cycle_Battery_Utilized_Ah * Batt_Const_V / 1000;                  % kW-hr
Cycle_Battery_Final_SOC           =  Batt_Initial_SOC - Cycle_Battery_Utilized_Ah/Batt_Capacity_Ah;    % Fraction (-)

% This is the energy used for the load
Cycle_Battery_Load_Utilized_kwhr  =  max(tout)/3600*Batt_Aux_Load_W/1000;                              % kW-hr


disp('  Battery Results:')
s = sprintf('\tBattery Charge(Capacity) =\t %6.3f \t(A-hr)' , Batt_Capacity_Ah);                         disp(s);
s = sprintf('\tBattery Charge(Initial)  =\t %6.3f \t(A-hr)' , Cycle_Battery_Initial_Charge_Ah);          disp(s);
s = sprintf('\tBattery Charge(Utilized) =\t %6.3f \t(A-hr)' , Cycle_Battery_Utilized_Ah);                disp(s);
disp(' ');
s = sprintf('\tBattery Energy(Capacity) =\t %6.3f \t(kW-hr)', Cycle_Battery_Capacity_Energy_kwhr);       disp(s);
s = sprintf('\tBattery Energy(Initial)  =\t %6.3f \t(kW-hr)', Cycle_Battery_Initial_Energy_kwhr);        disp(s);
s = sprintf('\tBattery Energy(Utilized) =\t %6.3f \t(kW-hr)', Cycle_Battery_Utilized_kwhr);              disp(s);
s = sprintf('\tBattery E Load(Utilized) =\t %6.3f \t(kW-hr)', Cycle_Battery_Load_Utilized_kwhr);         disp(s);
disp(' ');

%% Vehicle Parameters
Cycle_Battery_Fuel_Consumption_gal  = Cycle_Battery_Utilized_kwhr/E_Gas;                                        % Equivalent Gallons of Gasoline
Cycle_Total_Fuel_Consumption_gal    = Cycle_Engine_Fuel_Consumption_gal + Cycle_Battery_Fuel_Consumption_gal;      % Equivalent Gallons of Gasoline
Cycle_FE = Cycle_Vehicle_Distance_Traveled_miles/Cycle_Total_Fuel_Consumption_gal;

%% Output for Spring 2011 HW2 
Cycle_Engine_Fuel_Consumption_kg      = Cycle_Engine_Fuel_Consumption_gal*742/264.17;                % gal * rho(kg/m3) * m3/gal
Cycle_Engine_Fuel_Consumption_l_100km = Cycle_Engine_Fuel_Consumption_gal/Cycle_Vehicle_Distance_Traveled_miles ...
                                        * 3.78541178 * 62.1371192 ;   % (l/gal) * (miles/100km)
Cycle_Engine_Fuel_Economy_mpg         = Cycle_Vehicle_Distance_Traveled_miles/Cycle_Engine_Fuel_Consumption_gal;                                   
Cycle_Vehicle_Average_Speed_mph       = Cycle_Vehicle_Distance_Traveled_miles/max(tout) * ( 3600 / 1);                                   



disp('  Vehicle Results:')
s = sprintf('\tTime Traveled     (Vehicle) =\t %5.0f \t(sec)', max(tout));                                disp(s);
s = sprintf('\tDistance Traveled (Vehicle) =\t %5.3f \t(miles)', Cycle_Vehicle_Distance_Traveled_miles);  disp(s);
s = sprintf('\tFuel Consumption (Engine)   =\t %5.3f \t(gal)',   Cycle_Engine_Fuel_Consumption_gal);      disp(s);
s = sprintf('\tFuel Consumption (Battery)  =\t %5.3f \t(gal)',   Cycle_Battery_Fuel_Consumption_gal);     disp(s);
s = sprintf('\tFuel Consumption (Total)    =\t %5.3f \t(gal)',   Cycle_Total_Fuel_Consumption_gal);       disp(s);
s = sprintf('\tFuel Consumption (Total)    =\t %5.3f \tgal/100miles', Cycle_Total_Fuel_Consumption_gal*100/Cycle_Vehicle_Distance_Traveled_miles); disp(s);
s = sprintf('\tFuel Economy     (Engine)   =\t %5.2f \t(mpg)',   Cycle_Engine_Fuel_Economy_mpg);          disp(s);
s = sprintf('\tFuel Economy     (Total)    =\t %5.2f \t(mpg)',   Cycle_FE);                               disp(s);
disp(' ');
s = sprintf('\tSpeed Max Error  (Vehicle)  =\t %5.1f \t(#)',     Cycle_Vehicle_Speed_Control_Maximum_Error); disp(s);
s = sprintf('\tSpeed Contrl Errors(Vehicle)=\t %5.1f \t(#)',     Cycle_Vehicle_Speed_Control_Errors_Total_No); disp(s);
s = sprintf('\tSpeed Acc Metric (Vehicle)  =\t %5.1f \t(#)',     Cycle_Vehicle_Speed_Control_Accuracy_Metric); disp(s);

  % Cycle_Battery_Utilized_Ah                        1x1                 8  double              
  % Cycle_Engine_Fuel_Consumption_gal                1x1                 8  double              
  % Cycle_Vehicle_Distance_Traveled_miles            1x1                 8  double              
  % Cycle_Vehicle_Jerk_Max_mpscube                   1x1                 8  double              
  % Cycle_Vehicle_Jerk_Min_mpscube                   1x1                 8  double              
  % Cycle_Vehicle_Speed_Control_Accuracy_Metric      1x1                 8  double              
  % Cycle_Vehicle_Speed_Control_Errors_Total_No      1x1                 8  double              
  % Cycle_Vehicle_Speed_Control_Maximum_Error        1x1                 8
  % double        

  

%% -------------

%disp('_________ ');
%disp('');
%disp(sprintf('\t%8.3f', max(tout)));
%disp(sprintf('\t%8.3f', Cycle_Vehicle_Distance_Traveled_miles  ));
%disp(sprintf('\t%8.3f', Cycle_Engine_Fuel_Consumption_gal*1000 ));

disp('');
disp('_________ ');
disp('');

%% Sticker mpg code
if Cycle_Vehicle_Distance_Traveled_miles > 10
        sticker_mpg = 1/(0.001376 + (1.3466/Cycle_FE));
elseif Cycle_Vehicle_Distance_Traveled_miles > 7 && Cycle_Vehicle_Distance_Traveled_miles < 8
        sticker_mpg = 1/(0.003259 + (1.1805/Cycle_FE));
    else
        sticker_mpg = 0;

end

%% Perfomance calculation
 if Cycle_Vehicle_Distance_Traveled_miles > 0.70 && Cycle_Vehicle_Distance_Traveled_miles < 1.5
    for i = 1:10000
       
        if vel_mph_performance.Data(i) <= 20
            vel_performance_20 = vel_mph_performance.Data(i);
            time_performance_20 = vel_mph_performance.time(i);
        elseif vel_mph_performance.Data(i) <= 30
            vel_performance_30 = vel_mph_performance.Data(i);
            time_performance_30 = vel_mph_performance.time(i);
        elseif vel_mph_performance.Data(i) <= 60
            vel_performance_60 = vel_mph_performance.Data(i);
            time_performance_60 = vel_mph_performance.time(i);
        elseif vel_mph_performance.Data(i) <= 80
            vel_performance_80 = vel_mph_performance.Data(i);
            time_performance_80 = vel_mph_performance.time(i);
        elseif vel_mph_performance.Data(i) <= 100
            vel_performance_100 = vel_mph_performance.Data(i);
            time_performance_100 = vel_mph_performance.time(i);
            
        else
            break;
        end
%     s = sprintf('\t60-100 passing \t%8.3f',time_performance_80-time_performance_60); disp(s);    
        
    end
    
% s = sprintf('\t60-80 passing \t%8.3f',time_performance_80-time_performance_60); disp(s); 
% s = sprintf('\tMax speed \t%8.3f',max(vel_mph_performance.Data)); disp(s);
    
 %Calculation of squared error
 time_actual_20 = 1.9;
 time_actual_30 = 3.2;
 time_actual_50 = 6.9;
 time_actual_80 = 15.7;
 time_actual_100 = 29.5;
 
 
% A = ((time_actual_20-time_performance_20)^2 + (time_actual_30-time_performance_30)^2 + (time_actual_50-time_performance_50)^2 + (time_actual_80-time_performance_80)^2 + (time_actual_100-time_performance_100)^2);
% rms_error = sqrt(A);

% s = sprintf('\tPerformance Error \t%8.3f',rms_error); disp(s);
 end
 
%s = sprintf('\t Battery SOC at the end of cycle \t%8.3f',battery_soc.Data(length(battery_soc.Data))); disp(s); 
s = sprintf('\tSticker mpg \t%8.3f',sticker_mpg); disp(s);
 


s = (sprintf('\tMax tout \t%8.3f', max(tout))); disp(s);
s = (sprintf('\tCycle_Vehicle_Distance_Traveled_miles \t%8.3f', Cycle_Vehicle_Distance_Traveled_miles  )); disp(s);
s = (sprintf('\tCycle_Vehicle_Average_Speed_mph \t%8.3f', Cycle_Vehicle_Average_Speed_mph)); disp(s);
disp(sprintf('\t%8.3f', max(TEST_CYCLE(:,2))));
disp(sprintf('\t%8.3f', std(TEST_CYCLE(:,2))));
disp(sprintf('\t%8.3f', std(TEST_CYCLE(:,2))/max(TEST_CYCLE(:,2))*100));

s = (sprintf('\tCycle_Engine_Fuel_Consumption_kg \t%8.3f', Cycle_Engine_Fuel_Consumption_kg)); disp(s);
s = (sprintf('\tCycle_Engine_Fuel_Consumption_l_100km \t%8.3f', Cycle_Engine_Fuel_Consumption_l_100km)); disp(s); 
s = (sprintf('\tCycle_Engine_Fuel_Economy_mpg \t%8.3f', Cycle_Engine_Fuel_Economy_mpg)); disp(s);
s = (sprintf('\tCycle_Vehicle_Speed_Control_Maximum_Error \t%8.3f', Cycle_Vehicle_Speed_Control_Maximum_Error)); disp(s);
s = (sprintf('\tCycle_Vehicle_Speed_Control_Errors_Total_No \t%8.3f', Cycle_Vehicle_Speed_Control_Errors_Total_No)); disp(s);





return;

Cycle_DiagAnalysis;
Cycle_Diag_Engine;
Cycle_DiagPerformance;

  